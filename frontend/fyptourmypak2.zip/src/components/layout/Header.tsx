import React, { useState } from 'react'

import { Link } from 'react-router-dom'

import menu from '/public/menu.svg'

import profileicon from '/public/profileicon.jpg'



const Header = () => {
    const [isMenuOpen, setIsMenuOpen] = useState(false);

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  return (
    <header className="sticky top-0 z-10 bg-white ">
    <div className="bg-white">
      <div className="flex justify-between mx-auto py-0 mr-2 ml-2">
        <div className="mt-6 ">
                   <Link to={'/'} className="flex items-center gap-1">
         <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-8 h-8 -rotate-90">
           <path strokeLinecap="round" strokeLinejoin="round" d="M6 12L3.269 3.126A59.768 59.768 0 0121.485 12 59.77 59.77 0 013.27 20.876L5.999 12zm0 0h7.5" />
         </svg>
         <span className="font-bold text-xl">TourMyPak</span>
       </Link>
        </div>
        <div>
          
        </div>

        <nav className="hidden md:flex space-x-8 font-semibold my-6 ">
        <div className='flex mr-8 -mt-1'>
          {/* <img src={profileicon} alt='profileicon' className='h-[45px] w-[45px] rounded-full'/> */}
          <svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="#6b3729" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" className="lucide lucide-circle-user-round"><path d="M18 20a6 6 0 0 0-12 0"/><circle cx="12" cy="10" r="4"/><circle cx="12" cy="12" r="10"/></svg>
          <p className='mt-2 ml-1'>Talha</p>
          </div>
          <Link to="/" className='mt-1'>
            About Us
          </Link>
          <Link to="/" className='mt-1'>
            Contact
          </Link>
        </nav>

        {/* Side Menu Button for Small Screens */}
        <button
          className="md:hidden text-gray-600 focus:outline-none"
          onClick={toggleMenu}
        >
          <img src={menu} alt='menu image' />
         
          {/* <Menu className="h-6 w-6" /> */}
        </button>
      </div>

      {/* Side Menu */}
      {isMenuOpen && (
        <nav className="md:hidden bg-white py-4 px-8 space-y-4 absolute top-20 left-[100px] right-0 shadow-2xl rounded-xl justify-center">
        <div className='block px-4 py-2 text-gray-800 hover:bg-teal-700 rounded-md hover:underline'>
          <img src={profileicon} alt='profileicon' className='h-[45px] w-[45px] rounded-full'/>
          <p className='mt-2 ml-1'>Talha</p>
          </div>
          <Link  className="block px-4 py-2 text-gray-800 hover:bg-teal-700 rounded-md hover:underline" to="/">
            About Us
          </Link>
          <Link  className="block px-4 py-2 text-gray-800 hover:bg-teal-700 rounded-md hover:underline" to="/">
            Contact
          </Link>
         
          
        </nav>
      )}
    </div>
  </header>
  )
}

export default Header