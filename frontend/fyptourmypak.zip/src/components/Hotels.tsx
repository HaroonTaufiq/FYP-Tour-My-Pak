import React from 'react';
// import { Box, TextField } from '@mui/material';
// import { FlightTakeoff, CalendarToday, People } from '@mui/icons-material';

const Hotels = () => {

  return (
    <div>
      hotels
      {/* <Box
        display="flex"
        p={3}
        boxShadow={3}
        borderRadius={8}
      >
        <div className="flex flex-col md:flex-row gap-2" style={{ width: '100%' }}>
          <TextField
            label="Hotel / Area / Resort / City"
            placeholder="Bucharest, Romania"
            variant="outlined"
            fullWidth
            InputProps={{
              startAdornment: <FlightTakeoff />,
            }}
            sx={{ marginBottom: 2 }}
          />

          <TextField
            label="Check in"
            type="date"
            variant="outlined"
            fullWidth
            InputProps={{
              startAdornment: <CalendarToday />,
            }}
            sx={{ marginBottom: 2 }}
          />

          <TextField
            label="Check out"
            type="date"
            variant="outlined"
            fullWidth
            InputProps={{
              startAdornment: <CalendarToday />,
            }}
            sx={{ marginBottom: 2 }}
          />

          <TextField
            label="Rooms & guests"
            type="number"
            variant="outlined"
            fullWidth
            InputProps={{
              startAdornment: <People />,
            }}
            sx={{ marginBottom: 2 }}
          />
        </div>
      </Box> */}
    </div>
  );
};

export default Hotels;
