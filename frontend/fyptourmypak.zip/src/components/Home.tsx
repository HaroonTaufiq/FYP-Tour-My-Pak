import React from "react";
import heroposter from '/heroposter.svg';
import Header from "../components/layout/Header";
import FlightForm from "./FlightForm";
import RecentSearches from "./RecentSearches";
import FallIntoTravel from "./FallIntoTravel";
import MyFooter from "./MyFooter";
import mainimage from '../../public/main5.jpg'

function App() {
  return (
   
 
    <div>
      <Header/>
      
        {/* <img src={heroposter} alt="Heroposter"  />   */}
         <img src={mainimage} alt="Heroposter" className="  w-full h-[600px] object-cover"/>
      <div className=" relative -top-[500px]">
        <FlightForm />
      </div>
      <RecentSearches />
      <FallIntoTravel />
      <MyFooter />

      
    </div>
   
  );
}

export default App;
