import React from 'react'


import fallintotravelpic1 from '/public/fallintotravelpic1.svg'
import fallintotravelpic2 from '/public/fallintotravelpic2.svg'
import fallintotravelpic3 from '/public/fallintotravelpic3.svg'
import fallintotravelpic4 from '/public/fallintotravelpic4.svg'
const FallIntoTravel = () => {
  return (
    <div className=" mx-[70px]">
    <p className="h-9 self-stretch text-[32px] font-bold mb-7 ">Fall into travel</p>
<p className="mt-[16px] max-w-[800px] leading-7 mb-4  "> Going somewhere to celebrate this season? Whether you’re going home or somewhere to roam, we’ve got the travel tools to get you to your destination.</p>
<div className="flex flex-col md:flex-row md:gap-x-10 gap-y-6 mt-[25px]">
<div>
<img src={fallintotravelpic1} alt='travel img'/>
<p className="text-white text-[24px] -mt-10 ml-2">Melbourne</p>
<button className="flex h-12 justify-center items-center gap-1 self-stretch rounded px-4 py-2 bg-[#8DD3BB] mt-4">Book Flight</button>
</div>
<div>
<img src={fallintotravelpic2} alt='travel img'/>
<p className="text-white text-[24px] -mt-10 ml-2">Melbourne</p>
<button className="flex h-12 justify-center items-center gap-1 self-stretch rounded px-4 py-2 bg-[#8DD3BB] mt-4">Book Flight</button>

</div>
<div>
<img src={fallintotravelpic3} alt='travel img'/>
<p className="text-white text-[24px] -mt-10 ml-2">Melbourne</p>
<button className="flex h-12 justify-center items-center gap-1 self-stretch rounded px-4 py-2 bg-[#8DD3BB] mt-4">Book Flight</button>

</div>
<div>
<img src={fallintotravelpic4} alt='travel img'/>
<p className="text-white text-[24px] -mt-10 ml-2">Melbourne</p>
<button className="flex h-12 justify-center items-center gap-1 self-stretch rounded px-4 py-2 bg-[#8DD3BB] mt-4">Book Flight</button>

</div>


</div>


  </div>
  )
}

export default FallIntoTravel