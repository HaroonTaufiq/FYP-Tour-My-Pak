/* eslint-disable react-hooks/rules-of-hooks */
/* eslint-disable @typescript-eslint/no-unused-vars */
import React, { useEffect, useState, useRef, FC } from "react";
import Mytest from "./test";
import { Input } from "antd";

import { DateRange, Calendar } from "react-date-range";
import "react-date-range/dist/styles.css"; // main css file
import "react-date-range/dist/theme/default.css"; // theme css file

import { AutoComplete } from "antd";
import { useNavigate  } from 'react-router-dom';
import { Context } from "./StateContext";
// import AirportData from '@/app/airportdata'

const Oneway: FC<{ data?: any }> = ({ data }) => {
  console.log("oneway data", data);
  const airportCities = [
    { value: "New York ", code: "NYC", airport: "New York International " },
    {
      value: "Los Angeles",
      code: "LAX",
      airport: "Los Angeles International ",
    },
    { value: "London", code: "LON", airport: "London International " },
    { value: "Paris", code: "PAR", airport: "Paris International " },
    { value: "Tokyo", code: "TYO", airport: "Tokyo International " },
    // Add more airport cities and codes as needed
  ];

  const [airportdata, setAirportData] = useState([]);
  const today = new Date();

  const {startDate, setStartDate}:any = Context()
  const [dateInString, setDateInString] = useState(false);
  const [datePickerOpen, setDatePickerOpen] = useState(false);
  const {departureCity, setDepartureCity}:any = Context()
  const {arrivalCity, setArrivalCity}:any = Context()

    const {adults, setAdults}:any= Context()
    const {child, setchild}:any = Context()
    const {infant, setInfant}:any = Context()
    const {travelers, setTravelers}:any = Context()

  const defaultFocusRef = useRef<any>(null);
  const navigate = useNavigate(); // Get the router object

  // Function to navigate to flight listing page with data
  const navigateToFlightListing = () => {
    if (departureCity == "" || arrivalCity == "") {
      alert("fill in all fields");
      return;
    }
    // Construct the data object
    const searchData = {
      tripType: "oneway",
      departureCity,
      arrivalCity,
      startDate: startDate
        ? !dateInString
          ? startDate.toLocaleDateString()
          : startDate
        : "",
      adults: adults?.toLocaleString(),
      child: child?.toLocaleString(),
      infant: infant?.toLocaleString(),
      travelers: travelers?.toLocaleString(),
    };

    // Construct the query string
    const queryString = new URLSearchParams(searchData).toString();

    // Navigate to the flight listing page along with the query string
    navigate(`/flightslisting?${queryString}`);
  };

  const handleDepartureCityChange = (value: string) => {
    console.log("departure change oneway", value);
    setDepartureCity(value);
  };

  const handleArrivalCityChange = (value: string) => {
    setArrivalCity(value);
  };

  const handleClick = () => {
    setDatePickerOpen(!datePickerOpen);
    // You can perform other actions with the selected range here
  };

  // travelers


  useEffect(() => {
    async function fetchData() {
      console.log("in use effect");
      try {
        const response = await fetch("https://restcountries.com/v3.1/all");
        const data = await response.json();
        console.log("airportdata after fetch", data);
        setAirportData(data);
      } catch (error) {
        console.error("Error fetching country data:", error);
      }
    }

    fetchData();
  }, []); // Empty dependency array to ensure this runs only once on mount

  if (data) {
    useEffect(() => {
      if (data && data.tripType == "oneway") {
        // Set state variables using the parsed query parameters
        console.log("onway data in use effect", data);
        setDepartureCity(data.departureCity);
        setArrivalCity(data.arrivalCity);
        setDateInString(true);
        setStartDate(new Date(data.startDate));
        // setAdults(parseInt(data.adult)) ;
        // setchild(parseInt(data.child) );
        // setInfant(parseInt(data.infant) );
        // setTravelers(parseInt(data.travelers));
      }
    }, [data]);
  }

  return (
    <div>
      <div className="relative p-1">
        {/* <MyDropdown/> */}

        <Mytest data={data} />
      </div>
      <div className="flex flex-row custom-screen  mr-3 md:space-x-2  w-full ">
        <div className="max-h-[200px] min-w-[60px] mb-2 ">
          <AutoComplete
            defaultValue={departureCity}
            style={{ width: 300 }}
            onChange={handleDepartureCityChange}
            className="min-w-[300px] "
            options={airportdata.map((city: any) => ({
              value: `${city?.name.common}  `,
              code: city?.name.official,
              label: (
                <div className="flex mb-2">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    stroke-width="2"
                    stroke-linecap="round"
                    stroke-linejoin="round"
                    className="lucide lucide-plane mr-2"
                  >
                    <path d="M17.8 19.2 16 11l3.5-3.5C21 6 21.5 4 21 3c-1-.5-3 0-4.5 1.5L13 8 4.8 6.2c-.5-.1-.9.1-1.1.5l-.3.5c-.2.5-.1 1 .3 1.3L9 12l-2 3H4l-1 1 3 2 2 3 1-1v-3l3-2 3.5 5.3c.3.4.8.5 1.3.3l.5-.2c.4-.3.6-.7.5-1.2z" />
                  </svg>
                  <p className=" font-semibold">
                    {`${city?.name.common} `}
                    <br />
                    <span className="text-[12px]">
                      {`${city?.name.official}`}
                    </span>
                  </p>
                </div>
              ),
            }))}
            filterOption={(inputValue, option) => {
              return (
                option!.value
                  .toUpperCase()
                  .indexOf(inputValue.toUpperCase()) !== -1 ||
                option!.code.toUpperCase().indexOf(inputValue.toUpperCase()) !==
                  -1
              );
            }}
            onSelect={(value, option) => {
              handleDepartureCityChange(value);
            }}
          >
            <Input
              style={{ height: 50 }}
              placeholder="Departure City"
              onChange={(e) => setDepartureCity(e.target.value)}
            />
          </AutoComplete>
        </div>

        <div className="max-h-[50px] min-w-[60px] mb-2">
          <AutoComplete
            className="min-w-[300px] max-h-[200px] "
            defaultValue={arrivalCity}
            options={airportCities.map((city) => ({
              value: `${city.value} `,
              code: city.code,
              label: (
                <div className="flex mb-2 ">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    stroke-width="2"
                    stroke-linecap="round"
                    stroke-linejoin="round"
                    className="lucide lucide-plane mr-2"
                  >
                    <path d="M17.8 19.2 16 11l3.5-3.5C21 6 21.5 4 21 3c-1-.5-3 0-4.5 1.5L13 8 4.8 6.2c-.5-.1-.9.1-1.1.5l-.3.5c-.2.5-.1 1 .3 1.3L9 12l-2 3H4l-1 1 3 2 2 3 1-1v-3l3-2 3.5 5.3c.3.4.8.5 1.3.3l.5-.2c.4-.3.6-.7.5-1.2z" />
                  </svg>
                  <p className=" font-semibold">
                    {`${city.value} (${city.code})`}
                    <br />
                    <span className="text-[12px]">{`${city.airport}`}</span>
                  </p>
                </div>
              ),
            }))}
            filterOption={(inputValue, option) =>
              option!.value.toUpperCase().indexOf(inputValue.toUpperCase()) !==
              -1
            }
            onSelect={(value, option) => {
              handleArrivalCityChange(value);
            }}
          >
            <Input
              style={{ height: 50 }}
              placeholder="Arrival City"
              onChange={(e) => setArrivalCity(e.target.value)}
            />
          </AutoComplete>
        </div>

        <div className="max-h-[50px] min-w-[60px] relative mb-2">
          <AutoComplete
            className="min-w-[300px] "
            value={startDate ? `${startDate.toLocaleDateString()} ` : ``}
            onClick={handleClick}
          >
            <Input
              style={{ height: 50 }}
              placeholder="Departure Date"
              suffix={
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="black"
                  stroke-width="2"
                  stroke-linecap="round"
                  stroke-linejoin="round"
                  className="lucide lucide-calendar-days"
                >
                  <rect width="18" height="18" x="3" y="4" rx="2" ry="2" />
                  <line x1="16" x2="16" y1="2" y2="6" />
                  <line x1="8" x2="8" y1="2" y2="6" />
                  <line x1="3" x2="21" y1="10" y2="10" />
                  <path d="M8 14h.01" />
                  <path d="M12 14h.01" />
                  <path d="M16 14h.01" />
                  <path d="M8 18h.01" />
                  <path d="M12 18h.01" />
                  <path d="M16 18h.01" />
                </svg>
              }
            />
          </AutoComplete>
          <div>
            {datePickerOpen && (
              <div className=" flex  absolute z-10 top-0  bg-white ">
                <Calendar
                  onChange={(item) => setStartDate(item)}
                  date={startDate}
                  minDate={new Date()}
                  rangeColors={["#0f766e"]}
                />
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="#e11414"
                  stroke-width="2"
                  stroke-linecap="round"
                  stroke-linejoin="round"
                  className="lucide lucide-x-circle"
                  onClick={handleClick}
                >
                  <circle cx="12" cy="12" r="10" />
                  <path d="m15 9-6 6" />
                  <path d="m9 9 6 6" />
                </svg>
              </div>
            )}
          </div>
        </div>
      </div>
      <div className="flex justify-center ">
        <button
          type="submit"
          className=" mt-2 bg-teal-700 text-white px-7 py-4 rounded-md shadow-lg text-lg font-medium hover:shadow-lg hover:scale-105 duration-300 w-40"
          onClick={navigateToFlightListing}
        >
          Book now
        </button>
      </div>
    </div>
  );
};

export default Oneway;
