import React from 'react'
import recentSearchpic1 from '/public/recentsearchpic1.svg';
import recentSearchpic2 from '/public/recentsearchpic2.svg';
import recentSearchpic3 from '/public/recentsearchpic3.svg';
import recentSearchpic4 from '/public/recentsearchpic4.svg';


const RecentSearches = () => {
  return (
    <div className=" relative mx-[70px] -top-[70px]">
    <p className=" text-[32px] font-bold h-10 self-stretch mb-10">Your recent searches</p>
    <div className="flex flex-col md:flex-row md:gap-x-14 gap-y-7 mt-[25px]">
      <div className="flex">
      <img src={recentSearchpic1} alt="recent search icon" />
      <p className="text-[14px] font-bold  mt-6 ml-2">Istabnbul, Turkey</p>
      </div>
      <div className="flex">
      <img src={recentSearchpic2} alt="recent search icon" />
      <p className="text-[14px] font-bold mt-6 ml-2">Istabnbul, Turkey</p>
      </div>
      <div className="flex">
      <img src={recentSearchpic3} alt="recent search icon" />
      <p className="text-[14px] font-bold mt-6 ml-2">Istabnbul, Turkey</p>
      </div>
      <div className="flex">
      <img src={recentSearchpic4} alt="recent search icon" />
      <p className="text-[14px] font-bold mt-6 ml-2">Istabnbul, Turkey</p>
      </div>
    </div>
  </div>
  )
}

export default RecentSearches