import React from 'react';
// import { Box, TextField } from '@mui/material';
// import { FlightTakeoff, CalendarToday, People } from '@mui/icons-material';

const Insurance = () => {
  return (
    <div>
      Insurancce
    </div>
      // <Box display="flex" p={3} boxShadow={3} borderRadius={8}>
      //   <div className='flex flex-col'>
      //   <div className="flex flex-col md:flex-row md:gap-8" style={{ width: '100%' }}>
      //   <TextField
      //       label="Coverage Type"
      //       placeholder="Select Coverage Type"
      //       variant="outlined"
      //       fullWidth
      //       InputProps={{
      //         startAdornment: <FlightTakeoff />,
      //       }}
      //       sx={{ marginBottom: 2 }}
      //     />
      //     <TextField
      //       label="Origin"
      //       placeholder="Select Origin"
      //       variant="outlined"
      //       fullWidth
      //       InputProps={{
      //         startAdornment: <FlightTakeoff />,
      //       }}
      //       sx={{ marginBottom: 2 }}
      //     />
            
      //     </div>
      //   <div className="flex  flex-col md:flex-row md:gap-6 " >
         
      //     <TextField
      //         label="Travel Type"
      //         placeholder="Select Travel Type"
      //         variant="outlined"
      //         fullWidth
      //         InputProps={{
      //           startAdornment: <People />,
      //         }}
      //         sx={{ marginBottom: 2 }}
      //       />
           
      //       <TextField
      //         label="Destination"
      //         placeholder="Select Destination"
      //         variant="outlined"
      //         fullWidth
      //         InputProps={{
      //           startAdornment: <FlightTakeoff />,
      //         }}
      //         sx={{ marginBottom: 2 }}
      //       />
      
         
      //     <TextField
      //       label="DOB"
      //       type="date"
      //       variant="outlined"
      //       fullWidth
      //       InputProps={{
      //         startAdornment: <CalendarToday />,
      //       }}
      //       sx={{ marginBottom: 2 }}
      //     />
      //     <TextField
      //       label="Start date"
      //       type="date"
      //       variant="outlined"
      //       fullWidth
      //       InputProps={{
      //         startAdornment: <CalendarToday />,
      //       }}
      //       sx={{ marginBottom: 2 }}
      //     />
      //     <TextField
      //       label="End Date"
      //       type="date"
      //       variant="outlined"
      //       fullWidth
      //       InputProps={{
      //         startAdornment: <CalendarToday />,
      //       }}
      //       sx={{ marginBottom: 2 }}
      //     />
      //         </div>
      //     </div>
      
         
         
      // </Box>
   
  );
};

export default Insurance;
