/* eslint-disable react-hooks/rules-of-hooks */
/* eslint-disable @typescript-eslint/no-unused-vars */
import React, { useEffect, useState, useRef, FC } from "react";

import { Input } from "antd";

import { DateRange } from "react-date-range";

import { AutoComplete } from "antd";
import Mytest from "./test";
import { useNavigate } from "react-router-dom";
import { SearchOutlined } from '@ant-design/icons';
import { DownOutlined } from '@ant-design/icons';
import type { MenuProps } from 'antd';
import { Dropdown, Space,Button } from 'antd';
import { Context } from "./StateContext";
const RoundTrip : FC<{data?:any }> = ({data})  => {
  
  console.log("roundtrip data", data)
  const airportCities = [
    { value: 'New York ', code: 'NYC', airport:'New York International ' },
    { value: 'Los Angeles', code: 'LAX', airport:'Los Angeles International '  },
    { value: 'London', code: 'LON', airport:'London International '  },
    { value: 'Paris', code: 'PAR' , airport:'Paris International ' },
    { value: 'Tokyo', code: 'TYO', airport:'Tokyo International '  },
    // Add more airport cities and codes as needed
  ];
  const [airportdata,setAirportData]=useState([])
  const[dateInString,setDateInString]=useState(false)


  const {startDate, setStartDate}:any = Context()
  const fourDaysLater = new Date();
  fourDaysLater.setDate(startDate.getDate() + 4);

  const [endDate, setEndDate] = useState<Date|any>(fourDaysLater);

  const [datePickerOpen, setDatePickerOpen] = useState(false);
  const [datePickerOpen2, setDatePickerOpen2] = useState(false);
  const {departureCity, setDepartureCity}:any = Context()
  const {arrivalCity, setArrivalCity}:any = Context()
  const [departureDate, setDepartureDate] = useState<Date | null>(null);
  const [arrivalDate, setArrivalDate] = useState<Date | null>(null);
  const navigate = useNavigate(); // Get the router object

  // Function to navigate to flight listing page with data
  const navigateToFlightListing = () => {
    if(departureCity==''|| arrivalCity==''){
      alert("fill in all fields")
      console.log("in navigateToFlightListing")
      return
    }
    // Construct the data object
    const searchData = {
      tripType:"roundtrip",
      departureCity,
      arrivalCity,
      startDate: startDate ? (!dateInString? startDate.toLocaleDateString():startDate ) :``,
      endDate: endDate ? (!dateInString? endDate.toLocaleDateString():endDate ) :``,
      adults: adults?.toLocaleString(),
      child: child?.toLocaleString(),
      infant:  infant?.toLocaleString(),
      travelers:   travelers?.toLocaleString()

    };

    // Construct the query string
    const queryString= new URLSearchParams(searchData).toString();

    // Navigate to the flight listing page along with the query string
    navigate(`/flightslisting?${queryString}`);
  };

  const handleDepartureDateChange = (value: any) => {
    setDepartureDate(value);
  };
  const handleArrivalDateChange = (value: any) => {
    setArrivalDate(value);
  };

  const handleDepartureCityChange = (value: string) => {
    setDepartureCity(value);
  };

  const handleArrivalCityChange = (value: string) => {
    setArrivalCity(value);
  };

  const handleSelect = (ranges: any) => {
    setStartDate(ranges.selection.startDate);
    setEndDate(ranges.selection.endDate);
  };


  const handleClick = () => {
    setDatePickerOpen(!datePickerOpen);
    // You can perform other actions with the selected range here
  };

  const handleClick2 = () => {
    setDatePickerOpen2(!datePickerOpen);
  };

  const selectionRange = {
    startDate: startDate,
    endDate: endDate ,
    key: "selection",
  };

  // const formatDate = (date:any) => {
  //   const options:any = { day: "numeric", month: "long" };
  //   return new Intl.DateTimeFormat("en-US", options).format(date);
  // };

  // travelers
  const [open, setOpen] = useState(false);


    const {adults, setAdults}:any= Context()
    const {child, setchild}:any = Context()
    const {infant, setInfant}:any = Context()
    const {travelers, setTravelers}:any = Context()
const handleIncreaseAdults = () => {
    if (adults < 9) {
        setAdults(adults+ 1);
        setTravelers(travelers + 1);
    }
};

const handleDecreaseAdults = () => {
    if (adults > 0) {
        setAdults(adults - 1);
        setTravelers(travelers - 1);
    }
};
const handleIncreasechild = () => {
    if (child < 9) {
        setchild(child + 1);
        setTravelers(travelers + 1);
    }
};

const handleDecreasechild = () => {
    if (child > 0) {
        setchild(child - 1);
        setTravelers(travelers - 1);
    }
};
const handleIncreaseInfant = () => {
    if (infant < 9) {
        setInfant(infant + 1);
        setTravelers(travelers + 1);
    }
};
const handleDecreaseInfant = () => {
    if (infant > 0) {
        setInfant(infant - 1);
        setTravelers(travelers - 1);
    }
};




const handleMenuClick: MenuProps['onClick'] = (e) => {
    if (e.key === '4') {
        setOpen(false);
    }
};

const handleOpenChange = (flag: boolean) => {
    setOpen(flag);
};

const items: MenuProps['items'] = [
    {
        label: (
            <div style={{ display: 'flex', alignItems: 'center',marginRight:'15px' }}>
                <div style={{ flex:1}}>  <h1 >Adults</h1>  </div>
                <div>
              

                 
                <Button shape='circle' onClick={handleDecreaseAdults} style={{borderColor: "gray" }}>
                    -
                </Button>
                <span style={{ margin: '0 8px', fontWeight: '600' }}> {adults}</span>
                <Button shape='circle' onClick={handleIncreaseAdults} style={{borderColor: "gray" }}>
                    +
                </Button>
            </div>
            </div>),
        key: '1',
    },
    {
        label: (
    
                <div style={{ display: 'flex', alignItems: 'center' ,marginRight:'15px' }}>
                <div style={{ flex:1}}>  <h1>child</h1>  </div>
                <div>


                <Button shape='circle' onClick={handleDecreasechild} style={{borderColor: "gray" }}>
                    -
                </Button >
                <span style={{ margin: '0 8px', fontWeight: '600' }}> {child}</span>
                <Button shape='circle' onClick={handleIncreasechild} style={{borderColor: "gray" }}>
                    +
                </Button>
            </div>
            </div>),
        key: '2',
    },
    {
        label: (
            <div style={{ display: 'flex', alignItems: 'center', marginRight:'15px' }}>
                <div style={{ flex:1}}>  <h1>Infant</h1>  </div>
                <div >
                <Button shape='circle' onClick={handleDecreaseInfant} style={{borderColor: "gray" }}>
                    -
                </Button >
                <span style={{ margin: '0 8px', fontWeight: '600' }}> {infant}</span>
                <Button shape='circle' onClick={handleIncreaseInfant} style={{borderColor: "gray" }}>
                    +
                </Button>
            </div>
            </div>),
        key: '3',
    },
    {
        label: (
            <div>
                <Button type="primary" block icon={<SearchOutlined />} className='bg-teal-700'>
                    Search
                </Button>
            </div>
        ),
        key: '4',
    },
   
];

if(data)
{




useEffect(() => {
  
 
  if (data && data.endDate) {

  // Set state variables using the parsed query parameters
  setDepartureCity(data.departureCity );
  setArrivalCity(data.arrivalCity);
  setDateInString(true)
  setStartDate(new Date(data.startDate) );
  if(data.endDate){
  setEndDate(new Date(data.endDate) );
  }
  // setAdults(parseInt(data.adult)) ;
  // setchild(parseInt(data.child) );
  // setInfant(parseInt(data.infant) );
  // setTravelers(parseInt(data.travelers));
}

async function fetchData() {
  try {
    const response = await fetch('https://restcountries.com/v3.1/all');
    const data = await response.json();
   console.log('countries data is', data[0].name.common)

   setAirportData(data)
   console.log("setAirportData",data)
   if(data){
    const searchdata= data.map((city:any) => 
    city?.name.common
  )
  console.log("search data after mapping",searchdata)
   }
 
  } catch (error) {
    console.error('Error fetching country data:', error);
  }
}
fetchData();

}, [data]);
}
  return (
    <div>
      <div className="relative p-1">
        {/* <MyDropdown/> */}
        {/* <Dropdown
         
         overlayStyle={{ minWidth: '350px',height:'50%' } } 
            menu={{
                items,
                onClick: handleMenuClick,
            }}
            onOpenChange={handleOpenChange}
            open={open}
            placement="bottomLeft"  // Add this line to set the placement to "bottomLeft"
            getPopupContainer={(trigger:any) => trigger.parentNode} // Add this line to set the popup container
        >
            <a onClick={(e) => e.preventDefault()}>
                <Space className="text-white bg-teal-700 hover:bg-teal-900 focus:ring-4 focus:outline-none focus:ring-teal-300 font-medium rounded-lg text-sm px-2 py-1.5 text-center inline-flex items-center dark:bg-teal-600 dark:hover:bg-teal-700 dark:focus:ring-teal-800 mb-2" >
                    {`${travelers}Travelers`}
                    <DownOutlined />
                </Space>
            </a>
        </Dropdown> */}
        <Mytest data={data} />
        
      </div>
      <div className="flex flex-row custom-screen  mr-3 md:space-x-2  w-full ">
        <div className="max-h-[50px] min-w-[60px] ">
          <AutoComplete
              //  dataSource={airportCities.map(city => city.value)}
               defaultValue={departureCity}
             className='min-w-[300px] mb-2 '
            options={airportCities.map((city) => ({
              value: `${city.value} (${city.code}) `,
              code: city.code,
              label: (
                <div className="flex mb-2">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    stroke-width="2"
                    stroke-linecap="round"
                    stroke-linejoin="round"
                    className="lucide lucide-plane mr-2"
                  >
                    <path d="M17.8 19.2 16 11l3.5-3.5C21 6 21.5 4 21 3c-1-.5-3 0-4.5 1.5L13 8 4.8 6.2c-.5-.1-.9.1-1.1.5l-.3.5c-.2.5-.1 1 .3 1.3L9 12l-2 3H4l-1 1 3 2 2 3 1-1v-3l3-2 3.5 5.3c.3.4.8.5 1.3.3l.5-.2c.4-.3.6-.7.5-1.2z" />
                  </svg>
                  <p className=' font-semibold'>
                  {`${city.value} (${city.code})`}
                  <br />
                  <span className='text-[12px]'>
                  {`${city.airport}`}
                 </span>
                  </p>
             
                </div>
              ),
            }))}
            filterOption={(inputValue, option) =>
              option!.value.toUpperCase().indexOf(inputValue.toUpperCase()) !==
              -1
            }
            onSelect={(value, option) => {
           
              handleDepartureCityChange(value);
            }}
          >
            <Input style={{ height: 50 }} placeholder="Departure City" onChange={(e)=>setDepartureCity(e.target.value)} />
          </AutoComplete>
        </div>

        <div className="max-h-[50px] min-w-[60px] mb-2 ">
          <AutoComplete
              //  dataSource={airportCities.map(city => city.value)}
               defaultValue={arrivalCity}
             className='min-w-[300px] '
            options={airportCities.map((city) => ({
              value: `${city.value} (${city.code})`,
              code: city.code,
              label: (
                <div className="flex mb-2">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    stroke-width="2"
                    stroke-linecap="round"
                    stroke-linejoin="round"
                    className="lucide lucide-plane mr-2"
                  >
                    <path d="M17.8 19.2 16 11l3.5-3.5C21 6 21.5 4 21 3c-1-.5-3 0-4.5 1.5L13 8 4.8 6.2c-.5-.1-.9.1-1.1.5l-.3.5c-.2.5-.1 1 .3 1.3L9 12l-2 3H4l-1 1 3 2 2 3 1-1v-3l3-2 3.5 5.3c.3.4.8.5 1.3.3l.5-.2c.4-.3.6-.7.5-1.2z" />
                  </svg>
                  <p className=' font-semibold'>
                  {`${city.value} (${city.code})`}
                  <br />
                  <span className='text-[12px]'>
                  {`${city.airport}`}
                 </span>
                  </p>
             
                </div>
              ),
            }))}
            filterOption={(inputValue, option) =>
              option!.value.toUpperCase().indexOf(inputValue.toUpperCase()) !==
              -1
            }
            onSelect={(value, option) => {
             
              handleArrivalCityChange(value);
            }}
          >
            <Input style={{ height: 50 }} placeholder="Arrival City" onChange={(e)=>setArrivalCity(e.target.value)} />
          </AutoComplete>
        </div>

        <div className="max-h-[50px] min-w-[60px] relative mb-2">
          <AutoComplete
             className='min-w-[300px] '
         
            value={
              startDate && endDate
                ? `${startDate.toLocaleDateString()} - ${endDate.toLocaleDateString()}` 
                : ""
                
            }
            onClick={handleClick}
            onSelect={handleDepartureDateChange}
          >
            <Input
              style={{ height: 50 }}
              placeholder="Departure Date"
              suffix={
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="black"
                  stroke-width="2"
                  stroke-linecap="round"
                  stroke-linejoin="round"
                  className="lucide lucide-calendar-days"
                >
                  <rect width="18" height="18" x="3" y="4" rx="2" ry="2" />
                  <line x1="16" x2="16" y1="2" y2="6" />
                  <line x1="8" x2="8" y1="2" y2="6" />
                  <line x1="3" x2="21" y1="10" y2="10" />
                  <path d="M8 14h.01" />
                  <path d="M12 14h.01" />
                  <path d="M16 14h.01" />
                  <path d="M8 18h.01" />
                  <path d="M12 18h.01" />
                  <path d="M16 18h.01" />
                </svg>
              }
            />
          </AutoComplete>

          {datePickerOpen && (
            <div className=" flex  absolute z-10 top-0  bg-white ">
              <DateRange
                ranges={[selectionRange]}
                minDate={new Date()}
              
                onChange={handleSelect}
              />
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="24"
                height="24"
                viewBox="0 0 24 24"
                fill="none"
                stroke="#e11414"
                stroke-width="2"
                stroke-linecap="round"
                stroke-linejoin="round"
                className="lucide lucide-x-circle"
                onClick={handleClick}
              >
                <circle cx="12" cy="12" r="10" />
                <path d="m15 9-6 6" />
                <path d="m9 9 6 6" />
              </svg>
            </div>
          )}
        </div>

        
      </div>
      <div className="flex justify-center ">
  
      <button type="submit"className=' mt-2 bg-teal-700 text-white px-7 py-4 rounded-md shadow-lg text-lg font-medium hover:shadow-lg hover:scale-105 duration-300 w-40' onClick={navigateToFlightListing} >Book now</button>

    
</div>
    </div>
  );
};

export default RoundTrip;
